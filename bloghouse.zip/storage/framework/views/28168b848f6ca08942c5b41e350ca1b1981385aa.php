
<?php $__env->startSection('content'); ?>

    <div class="container py-4">
        <a href="<?php echo e(url()->previous()); ?>"><button type="button" class="btn btn-outline-dark">Go Back</button></a>
        <h1 class="py-4"><?php echo e(ucfirst($post->title)); ?></h1>
        <div class="text-center">
            <img src="<?php echo e(url('/cover_images/' .$post->cover_image)); ?>" alt="Image" style="width: 60%; height: 50%" class="img-thumbnail">
        </div>
        <br><br>
        <div>
            
            
           <p> <?php echo $post->body; ?></p>
        </div>
        <hr>
        <small>created by <strong><?php echo e(ucwords($post->user->name)); ?></strong></small>
        <hr>
        <small>Written on <?php echo e($post->created_at->format('M-d-Y')); ?></small>
        <hr>
        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>
            <a href="/posts/<?php echo e($post->id); ?>/edit"><button type="button" class="btn btn-outline-info">Edit Blog</button></a>
            <div class="float-right">
            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" name="delete" class="btn btn-outline-danger" onclick="return confirm('Are you sure?')" value="Delete Blog">
            </form>
            </div>
     </div>
    <?php endif; ?>
    <?php endif; ?>

    
    <div class="comments container py-5">
            
     <h5>Comments <small><?php echo e($post->comments()->count()); ?></small></h5>
    
     
     <?php echo $__env->make('posts.commentsDisplay', ['comments' => $post->comments, 'post_id' => $post->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(auth()->guard()->check()): ?>
    
        <div class="card-body">
            <h5>Leave a comment</h5>
            <form method="post" action="<?php echo e(route('comments.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <textarea class="form-control" name="body"></textarea>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-sm btn-outline-danger py-0" style="font-size: 0.8em;" value="Add Comment">
                </div>
        </div>
    </div>
    
     <?php endif; ?>

     
     <?php if(auth()->guard()->guest()): ?>
     <div class="py-5 px-4">
     <a href="/login"><p>Login to comment</p></a>
    </div>
     <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\bloghouse\resources\views//posts/show.blade.php ENDPATH**/ ?>