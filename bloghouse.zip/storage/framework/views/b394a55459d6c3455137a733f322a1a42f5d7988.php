
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <a href="/posts"><button type="button" class="btn btn-outline-dark">Go Back</button></a>
      <h1>Edit Blog</h1>
       <form method="POST" action="<?php echo e(route('posts.update')); ?>">
           <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="title">Title</label>
              <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="title" value="<?php echo e($post->title); ?>">
              <small id="emailHelp" class="form-text text-muted">Create a beautiful blog!</small>
          </div>
          <div class="form-group">
          <label for="body">Body</label>
          <textarea class="form-control" id="validationTextarea" name="body"><?php echo e($post->title); ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
      </form>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\bloghouse\resources\views/posts/edit.blade.php ENDPATH**/ ?>