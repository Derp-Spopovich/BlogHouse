<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    
    <div class="display-comment" <?php if($comment->parent_id != null): ?> style="margin-left:40px;" <?php endif; ?>>
        <small class="float-right"><?php echo e($comment->created_at->diffForHumans()); ?></small>
        <strong><?php echo e($comment->user->name); ?></strong>
        <p><?php echo e($comment->body); ?></p>
        <a href="" id="reply"></a>
        

        <?php if(auth()->guard()->check()): ?>
        
        <form method="post" action="<?php echo e(route('comments.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="body" class="form-control" />
                <input type="hidden" name="post_id" value="<?php echo e($post_id); ?>" />
                <input type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>" />
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-sm btn-outline-danger py-0" style="font-size: 0.8em;" value="Reply" />
            </div>
        </form>
        <?php endif; ?>
       
         
         <?php if(Auth::user() && (Auth::user()->id == $comment->user_id)): ?>
         <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="post" class="float-none">
             <?php echo csrf_field(); ?>
             <?php echo method_field('DELETE'); ?>
             <input type="submit" class="btn btn-sm btn-outline-danger py-0 " name="delete"  onclick="return confirm('Are you sure?')" value="delete">
         </form>
         <?php endif; ?>

        <?php echo $__env->make('posts.commentsDisplay', ['comments' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\laravel\bloghouse\resources\views/posts/commentsDisplay.blade.php ENDPATH**/ ?>