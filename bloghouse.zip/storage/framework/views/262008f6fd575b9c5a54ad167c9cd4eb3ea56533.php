<hr class="featurette-divider my-4">
<footer class="container py-3">
    <p>&copy; 2020 Hanphil Lim &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel\bloghouse\resources\views/inc/footer.blade.php ENDPATH**/ ?>