<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <h3>Your Blog Posts</h3>
                    <a href="/posts/create">Create New Blog</a>
                    
                    <?php if(count($posts) > 0): ?>
                        <table class="table table-striped">
                            <tr>
                                <td>Title</td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($post->title); ?></td>
                                <td><a href="/posts/<?php echo e($post->id); ?>" class="btn btn-outline-dark">View</a></td>
                                <td><a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-outline-info">Edit</a></td>
                                <td>
                                    <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post" class="float-right">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="submit" value="Delete Blog" name="delete" onclick="return confirm('Are you sure?')" class="btn btn-outline-danger ">
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php else: ?>
                        <p>You have no blog posted yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\bloghouse\resources\views/home.blade.php ENDPATH**/ ?>