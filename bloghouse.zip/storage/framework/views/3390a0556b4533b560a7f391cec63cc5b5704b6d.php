
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    
    <div>
        <div class="mx-auto float-right">
            <div class="">
                <form action="<?php echo e(route('posts.index')); ?>" method="GET" role="search">
                    <div class="input-group">
                        <a href="/posts"><svg width="5em" height="2em" viewBox="0 0 16 16" class="bi bi-arrow-repeat" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z"/>
                            <path fill-rule="evenodd" d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z"/>
                          </svg></a>
                        <input type="text" class="form-control mr-2" name="term" placeholder="Search Blog By Title" id="term">
                        <span class="input-group-btn mr-5">
                        <button class="btn btn-outline-info" type="submit" title="Search Blog">
                            search
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    <h1>Blogs</h1>
    <a href="/posts/create" class="badge badge-pill badge-primary">Create New Blog</a>
  

    <?php if(count($posts) > 0): ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container marketing">
        <hr class="featurette-divider">
            <div class="row featurette">
                <div class="col-md-7 order-md-2 py-5">
                    <h2 class="featurette-heading"><?php echo e(ucfirst($post->title)); ?></h2>
                    <p class="lead">Created By: <?php echo e(ucwords($post->user->name)); ?></p>
                    <p class="lead">Date Created: <?php echo e($post->created_at->format('M-d-Y')); ?></p>
                    <a href="/posts/<?php echo e($post->id); ?>"><button class="btn btn-outline-info">View Blog</button>
                </div>
                    <div class="col-md-5">
                        
                        <img src="<?php echo e(url('/cover_images/' .$post->cover_image)); ?>" alt="photo" class="bd-placeholder-img card-img-top img-thumbnail imgindex" style="width: 95%;">
                    </a>
                    
                </div>
            </div>
    </div>

   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="py-5 mx-4">
        <?php echo e($posts->links()); ?>

    </div>

    <?php else: ?>
    <p class="py-5">There are no blogs</p>
    <?php endif; ?>
   
  

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\bloghouse\resources\views/posts/index.blade.php ENDPATH**/ ?>